import{b as a}from"../chunks/entry.vDuNN5Ar.js";export{a as start};
