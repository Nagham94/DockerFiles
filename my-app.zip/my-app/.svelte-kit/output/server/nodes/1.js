

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.DWB7TpSF.js","_app/immutable/chunks/scheduler.Dk-snqIU.js","_app/immutable/chunks/index.B-IpIKmi.js","_app/immutable/chunks/stores.Cl5uAfqw.js","_app/immutable/chunks/entry.vDuNN5Ar.js","_app/immutable/chunks/index.Ice1EKvx.js"];
export const stylesheets = [];
export const fonts = [];
